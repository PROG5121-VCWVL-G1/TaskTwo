/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog5121_poe;
import javax.swing.*;
/**
 *
 * @author ST10173642
 */
public class PROG5121_POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Register re = new Register();
        re.setVisible(true);
        Registration reg = re.r;
        Login l = new Login();
        l.setUsername(reg.getUsername());
        l.setPassword(reg.getPassword());
        String user = l.getUsername();
        String pass = l.getPassword();
        re.setVisible(false);
        
        Login2 log = new Login2();
        log.setVisible(true);
        String username = log.getUsername();
        String password = log.getPassword();
        if(username.equals(user)&&pass.equals(password))
        {
            JOptionPane.showMessageDialog(null,"You have logged in");
        }
        else
        {
            Login2 log2 = new Login2();
        }
    }
    
}
