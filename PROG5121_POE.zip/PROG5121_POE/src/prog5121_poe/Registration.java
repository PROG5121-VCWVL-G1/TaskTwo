/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog5121_poe;
import javax.swing.*;
/**
 *
 * @author ST10173642
 */
public class Registration {
    private String username;
    private String password;
    private String name;
    private String lastName;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
        if(username.length() > 5)
        {
            JOptionPane.showMessageDialog(null,"Enter an username of five characters with an underscore");
            Register r = new Register();
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
